#include <iostream>
#include "birthday.h"
#include "people.h"
using namespace std;


People::People(string x,Birthday Birthob)
:name(x),Dateofbirth(Birthob)
{

}

void People::Printinfo(){

cout<< name<<"was born on ";
Dateofbirth.Printdate();
}
