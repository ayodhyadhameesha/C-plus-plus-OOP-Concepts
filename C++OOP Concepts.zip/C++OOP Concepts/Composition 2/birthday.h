#ifndef BIRTHDAY_H
#define BIRTHDAY_H
#include <iostream>
using namespace std;

class Birthday
{
public:
    Birthday(int y,int m,int d);
    void Printdate();

    private:
        int year;
        int month;
        int day;
};

#endif // BIRTHDAY_H
