#include <iostream>
#include "birthday.h"
#include "people.h"
using namespace std;


Birthday::Birthday(int y,int m,int d)
{
  int year=y;
  int  month=m;
  int  day=d;
}


void  Birthday::Printdate(){
cout<<year<< "/"<<month<< "/"<<day<<endl;
}
