#include <iostream>
#include "birthday.h"
#include "people.h"
using namespace std;

int main()
{
Birthday bo(1997,2,16);
People peo("Ayodhya lord ",bo);
peo.Printinfo();
    return 0;
}
