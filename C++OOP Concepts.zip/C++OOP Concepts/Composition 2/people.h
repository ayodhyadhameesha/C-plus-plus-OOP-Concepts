#ifndef PEOPLE_H
#define PEOPLE_H
#include<string>
using namespace std;


class People
{
    public:

        People(string x,Birthday Birthob);
        void Printinfo();


    private:
        string name;
        Birthday Dateofbirth;
};

#endif // PEOPLE_H
