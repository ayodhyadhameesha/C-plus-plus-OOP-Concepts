#include <iostream>

using namespace std;

class ayodhya
{ public:
    void abaya() {
        cout<< "My name is abaya";

    }
};

int main()
{
    ayodhya objecte;
    objecte.abaya();

    return 0;
}
