#include <iostream>

using namespace std;

int main()
{
    int fish =5;
    &fish;
    cout<<&fish<<endl;
    int *fishPointer;
    fishPointer= &fish;
cout<<fishPointer<<endl;
    return 0;
}
