#include <iostream>

using namespace std;

int main()
{
    int ayo[5];
    int *bpo=&ayo[0];
    int *bp1=&ayo[1];
    int *bp2=&ayo[2];


    cout<< "bpo is at "<<bpo<<endl;
    cout<< "bp1 is at "<<bp1<<endl;
    cout<< "bp2 is at "<<bp2<<endl;

    bpo++;
    cout<< "bpo is now at "<<bpo<<endl;
    return 0;
}
