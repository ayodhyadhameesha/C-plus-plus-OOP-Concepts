#include <iostream>

using namespace std;

class Enemy{

protected:
    int Attackpower;
public:
    void Setattackpower(int a){

    Attackpower=a;

    }


};
class Ninja: public Enemy{

public:
  void Attack(){

    cout<< "Ninja is going to chop you - "<<Attackpower<<endl;

    }


};


class Monster: public Enemy{

public:
  void Attack(){

    cout<< "Monster is going to eat you - "<<Attackpower<<endl;

    }


};










int main()
{
  Ninja n;
  Monster m;
  n.Setattackpower(10);
  m.Setattackpower(25);
n.Attack();
m.Attack();
    return 0;
}
