#include <iostream>
#include "destruction.h"
#include <stdlib.h>
using namespace std;

Destruction::Destruction()
{
    cout<< "Iam a constructor"<<endl;
}

Destruction::~Destruction()
{   system("Pause");
    int a;
    cout<< "Destruction is runing\nPress any key to clean"<<endl;
    cin>>a;
    system("CLS");
}
