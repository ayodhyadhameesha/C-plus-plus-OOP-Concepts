#include <iostream>
#include "destruction.h"
using namespace std;

int main()
{
    Destruction object;
    cout<< "Iam the king"<<endl;

    return 0;
}
