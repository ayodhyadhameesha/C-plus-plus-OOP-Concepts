#ifndef DESTRUCTION_H
#define DESTRUCTION_H


class Destruction
{
    public:

        Destruction();

        virtual ~Destruction();


    private:
};

#endif // DESTRUCTION_H
