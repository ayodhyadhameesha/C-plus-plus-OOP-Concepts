#ifndef CONSRUCTOR_H
#define CONSRUCTOR_H


class Consructor
{
    public:

        Consructor();
        void display();


    private:
int a;
};

#endif // CONSRUCTOR_H
