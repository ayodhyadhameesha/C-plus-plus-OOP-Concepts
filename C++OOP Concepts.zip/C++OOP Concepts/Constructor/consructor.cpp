#include <iostream>
#include "consructor.h"
using namespace std;

Consructor::Consructor()
{
    int a=98;
}

void Consructor::display(){

cout<< "The value is "<<a<<endl;

}
