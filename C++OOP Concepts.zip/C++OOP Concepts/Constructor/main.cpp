#include <iostream>

using namespace std;



class Ayodhya{
int data,value;


 public:
     Ayodhya(){
data=50;
value=80;
cout<< "What is your name\n";
     }
    void display(){

    cout<< "The value is "<<data<<endl;
    }
    int addition(){

    cout<<data+value<<endl;

    }


};
int main()
{

Ayodhya ob1;
ob1.display();
Ayodhya ob2;
ob2.addition();



    return 0;
}
