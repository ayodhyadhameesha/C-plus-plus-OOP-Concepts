#include <iostream>

using namespace std;

class Enemy{

public:
    virtual void attack(){
cout<< "attack is my life\n";

    }




};
class Ninja: public Enemy{

public:
    void attack(){
        cout<< "Ninja attack chop chop\n";
    }

};


class Monster: public Enemy{

public:
void attack(){
        cout<< "Monster attack eat!eat!\n";
    }


};



int main()
{
    Ninja n;
    Monster m;
    Enemy e;
    e.attack();
    m.attack();
    n.attack();

}
