#include <iostream>
#include "marks.h"
using namespace std;


Marks::Marks(int a)
{ int x=a;
    cout<< "The marks you obtained is "<<x<<endl;
}

int Marks::Display(){
int a;
int x=a;

cout<< "It is called"<<x<<endl;


}
