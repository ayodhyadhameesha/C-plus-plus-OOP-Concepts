#ifndef MARKS_H
#define MARKS_H


class Marks
{
    public:

        Marks(int a);
        int Display();

    protected:

    private:
        int x;
};

#endif // MARKS_H
