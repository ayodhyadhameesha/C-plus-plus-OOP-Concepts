#include <iostream>
#include "marks.h"
using namespace std;



int main()
{
Marks ob1(23),ob2(22);
ob1.Display();
ob2.Display();

    return 0;
}
