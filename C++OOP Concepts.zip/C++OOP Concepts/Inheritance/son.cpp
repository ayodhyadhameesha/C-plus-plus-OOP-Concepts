#include <iostream>
#include "mother.h"
#include "son.h"
using namespace std;

Son::Son()
{
    //ctor
}
