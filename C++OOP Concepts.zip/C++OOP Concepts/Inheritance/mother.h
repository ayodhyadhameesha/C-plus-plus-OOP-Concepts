#ifndef MOTHER_H
#define MOTHER_H


class Mother
{
    public:

        Mother();
       void Sayname();
       void Callsis();

};

#endif // MOTHER_H
