#include <iostream>
#include "mother.h"
#include "son.h"
using namespace std;

Mother::Mother()
{

}
void Mother::Sayname(){

cout<< "Ayodhya please take the tea\n";

}

void Mother::Callsis(){

cout<< "Malli Please bring my tea\n";

}
