#include <iostream>
#include "daughter.h"
#include "mom.h"
using namespace std;

Daughter::Daughter()
{

}
