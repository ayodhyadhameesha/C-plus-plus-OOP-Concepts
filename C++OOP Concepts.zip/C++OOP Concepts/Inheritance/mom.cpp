#include <iostream>
#include "daughter.h"
#include "mom.h"
using namespace std;

Mom::Mom()
{

}
void sisi(){

cout<< "Son please take the tea\n";
}

void Saysister(){
cout<< "Sister please bring my tea\n";


}
