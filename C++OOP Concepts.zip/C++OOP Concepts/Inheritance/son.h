#ifndef SON_H
#define SON_H


class Son: public Mother
{
    public:

        Son();


};

#endif // SON_H
