#include <iostream>
#include "mother.h"
#include "son.h"
using namespace std;

int main()
{

Mother tea;
tea.Sayname();

Son bring;
bring.Callsis();


    return 0;
}
