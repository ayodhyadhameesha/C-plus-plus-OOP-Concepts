#ifndef DAUGHTER_H
#define DAUGHTER_H


class Daughter
{
    public:

        Daughter();


};

#endif // DAUGHTER_H
