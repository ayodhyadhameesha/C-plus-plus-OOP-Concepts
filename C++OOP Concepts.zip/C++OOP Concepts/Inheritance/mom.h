#ifndef MOM_H
#define MOM_H


class Mom
{
    public:

        Mom();
        void Sayname();
        void sisi();

};

#endif // MOM_H
