#include <iostream>
#include "birthday.h"
#include "people.h"
using namespace std;
int main()
{
Birthday Birthobj(1997,2,16);
People Ayodhya( "Ayodhya Lord ",Birthobj);
Ayodhya.Printinfo();

    return 0;
}
