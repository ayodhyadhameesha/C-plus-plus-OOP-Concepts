#ifndef BIRTHDAY_H
#define BIRTHDAY_H


class Birthday
{
    public:

        Birthday(int y,int m,int d);
     void Printdate();


    private:
        int year;
        int month;
        int date;
};

#endif // BIRTHDAY_H
