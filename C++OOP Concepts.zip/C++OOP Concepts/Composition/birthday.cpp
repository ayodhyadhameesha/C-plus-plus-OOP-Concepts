#include <iostream>
#include "birthday.h"
using namespace std;


Birthday::Birthday(int y,int m,int d){
    int year=y;
    int month=m;
    int date=d;
}

void Birthday::Printdate(){

cout<<year<< "/"<<month<< "/"<< date<<endl;

}
