#ifndef AYO_H
#define AYO_H


class Ayo
{
    public:
        /** Default constructor */
        Ayo();

    protected:

    private:
};

#endif // AYO_H
