#include "ayo.h"

Ayo::Ayo()
{
    //ctor
}
