#include <iostream>
#include "birthday.h"
#include "people.h"
using namespace std;

People::People(string x,Birthday bo)
:name(x),Dateofbirth(bo)

{
}

void People::Printinfo(){

cout<<name<< "was born on";
Dateofbirth.Printdate();

}
