#ifndef PEOPLE_H
#define PEOPLE_H
#include<string>
#include "birthday.h"
using namespace std;
class People
{
    public:

        People(string x,Birthday bo);
        void Printinfo();



    private:
        string name;
        Birthday Dateofbirth;
};

#endif // PEOPLE_H
